with open(r"C:\Users\csipak.miklos\Desktop\info\10d_csipak_miklos\input.txt", "r") as file:
    raw = ""
    for line in file:
        raw += line
    
char = " "
sors = [list(map(int, x.split(char))) for x in raw.splitlines()]
print(sors)

elso, masodik, harmadik, negyedik, otodik = sors

print("2. feladat")
valasz = sum([x**2 for x in elso if x % 3 == 0])
print("Az 1. sorban szereplő hárommal osztható számok négyzeteinek összege:", valasz)

print("3. feladat")
valasz = max([x for x in masodik if x > 17])
print("A  2. sorban szereplő 17-nél nagyobb számok maximuma:", valasz)

print("4. feladat")
valasz = sum([x for x in harmadik if x < 17]) / 2
print("A  3. sorban szereplő 17-nél kisebb számok számtani közepe:", valasz)

print("5. feladat")
valasz = sorted(negyedik)[-17]
print("A  4. sorban szereplő 17 legnagyobb szám minimuma:", valasz)

print("6. feladat")
valasz = sum(sorted(otodik)[0:15])
print("Az 5. sorban szereplő 15 legkisebb szám összege:", valasz)

print("7. feladat")
paratlanok = [x for x in elso + masodik + harmadik + negyedik + otodik if x % 2 != 0]
prod = 1
for num in paratlanok: prod *= num
valasz = str(len(str(prod)))
print("Az inputban szereplő összes szám közül a páratlan számok szorzatának nagyságrendje:", "10^" + valasz)